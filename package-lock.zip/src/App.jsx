import { useState } from "react";
import "./App.css";
import "./fonts.css"; // Import the fonts CSS file

function App() {
  return (
    <>
      <div className="font-poppins h-screen w-screen m-0 p-0 overflow-hidden fixed inset-0">
        <div className="flex justify-between w-full lg:px-16 px-4">
          <p className="font-bold">
            COMPUTER SCIENCE STUDENT
          </p>
          <p className="">
            BASED IN COLOMBO, LK.
          </p>
          <div>
            <p className="hidden lg:block">
              PASSIONATE UI/UX AND GRAPHIC DESIGNER CRAFTING SEAMLESS
              EXPERIENCES SINCE 2017. WITH A STRONG FOUNDATION IN BRANDING AND
              VISUAL STORYTELLING, I BLEND CREATIVITY AND STRATEGY TO BRING
              DESIGNS TO LIFE.
            </p>
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
